# Pairing Constraints Index

| Sub-Category | File | Resources |
|-------------|------|-----------|
| AI & ML | [ai-ml.md](ai-ml.md) | AI Search, Cognitive Services, ML Workspace |
| Compute (PaaS) | [compute-apps.md](compute-apps.md) | App Service, ASP, Function App, Container App, CAE, ACR, Static Web App |
| Compute (IaaS) | [compute-infra.md](compute-infra.md) | AKS, VM, VMSS, Availability Set, Managed Disk |
| Data (Relational) | [data-relational.md](data-relational.md) | SQL Server, SQL Database, MySQL, PostgreSQL |
| Data (Analytics) | [data-analytics.md](data-analytics.md) | Cosmos DB, Redis, Storage, Data Factory, Synapse |
| Messaging | [messaging.md](messaging.md) | Event Grid, Event Hub, Service Bus |
| Monitoring | [monitoring.md](monitoring.md) | App Insights, Log Analytics |
| Networking (Core) | [networking-core.md](networking-core.md) | VNet, Subnet, NSG, Route Table, NIC, Public IP, NAT Gateway |
| Networking (Traffic) | [networking-traffic.md](networking-traffic.md) | App Gateway, Front Door, LB, APIM |
| Networking (Connectivity) | [networking-connectivity.md](networking-connectivity.md) | Bastion, Firewall, VPN GW, DNS, Private DNS, PE |
| Security | [security.md](security.md) | Key Vault, Managed Identity |
