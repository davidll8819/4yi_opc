<template>
  <NuxtPage />
</template>