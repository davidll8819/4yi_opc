# Extensions

An **extension** overrides or adds an `agents-cli` command — to run a different agent framework, apply an org's deploy policy, or add a command of your own, without forking the tool.

- **[Using extensions](using.md)** — what extensions can do, how they work, and how to adopt, scope, and operate one.
- **[Authoring extensions](authoring.md)** — write the `agents-cli-extension.yaml` schema.
- **[First-party frameworks](first-party.md)** — the framework templates we maintain (LangChain today).
